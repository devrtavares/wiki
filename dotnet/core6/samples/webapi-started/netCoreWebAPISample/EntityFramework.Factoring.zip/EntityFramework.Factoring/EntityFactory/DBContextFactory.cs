﻿using Factory.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramework.Factoring.EntityFactory
{
    public class DbContextFactory : _ApplicationFactory
    {
        public static DbContext GetDalContainer(string identifyObjectId)
        {
            return _FactoryManager[identifyObjectId] as DbContext;
        }
    }
}
