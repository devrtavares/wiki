﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Factory.Models
{
    internal interface IApplicationFactory
    {
        void SetAdditionalProperties(_FactoryManager manager);
        _FactoryManager CreateFactoryManager(IPrincipal principal);
    }
}
