﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Factory.Models
{
    internal interface IFactoryManager
    {
        object this[string name] { get; set; }
        IPrincipal Principal { get; set; }
        static Func<_FactoryManager> CreateFactoryManager { get; }
        void RegisterConstructor(string name, Func<_FactoryManager, object> constructorDelegate);
        Func<_FactoryManager, object> GetConstructor(string name);
        object CreateNewObject(string name);
        event Action OnDispose;
    }
}
