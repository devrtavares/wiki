Create Table Users 
(
	id bigint not null identity(1,1),
	[Name] Nvarchar(48) Not Null,
	[LastName] Nvarchar(128),
	[TimeStamp] TimeStamp,
	CONSTRAINT [PK_Users] PRIMARY KEY (Id)
)

Create Table UsersCredentials 
(
	id bigint not null identity(1,1),
	[Password] NVarchar(255),
	[OtpSecret] NVarchar(255),
	[OtpFormat] NVarchar(128),
	[OtpTime] NVarchar(128),
	[gpgPublic] NVarchar(255),
	[gpgPrivate] Nvarchar(255),
	[2FA] Text,
	constraint [FK_UserCredentials] FOREIGN KEY (id) references [Users] (id)
)