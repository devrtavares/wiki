﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Factory.Models
{
    public abstract class _FactoryManager : IFactoryManager
    {
        private Dictionary<string, object> _properties = new Dictionary<string, object>();
        private Dictionary<string, Func<_FactoryManager, object>> _constructors = new Dictionary<string, Func<_FactoryManager, object>>();

        public object this[string name] { get => getName(name); set => setName(name, value); }

        private object getName(string name)
        {
            object value;
            if (_properties.TryGetValue(name, out value))
            {
                var constructor = GetConstructor(name);
                if (constructor != null)
                {
                    value = constructor.Invoke(this);
                    _properties[name] = value;
                }
            }
            return value;
        }
        private void setName(string name, object val)
        {
            _properties[name] = val;
        }

        public IPrincipal Principal { get; set; }
        public static Func<_FactoryManager> CreateFactoryManager { get; }

        public event Action OnDispose;

        public object CreateNewObject(string name)
        {
            var constructor = GetConstructor(name);
            if (constructor != null)
            {
                return constructor.Invoke(this);
            }
            return null;
        }

        public object Clone()
        {
            if (this._constructors == null || this._properties == null)
            {
                throw new ObjectDisposedException("Application context if already disposed");
            }
            _FactoryManager cloned = _FactoryManager.CreateFactoryManager();
            cloned.Principal = this.Principal;
            foreach (var item in this._constructors)
            {
                cloned._constructors.Add(item.Key, item.Value);
            }
            foreach (var item in this._properties)
            {
                if(!(item.Value is IDisposable))
                    cloned._properties.Add(item.Key, item.Value);
            }
            return cloned;
        }

        public Func<_FactoryManager, object> GetConstructor(string name)
        {
            Func<_FactoryManager, object> constructorDelegate = null;
            if(_constructors.TryGetValue(name, out constructorDelegate))
            {
                return constructorDelegate;
            }
            return null;
        }

        public void RegisterConstructor(string name, Func<_FactoryManager, object> constructorDelegate)
        {
            _constructors[name] = constructorDelegate;
        }

        public void Dispose()
        {
            Dispose(true);
        }

        public virtual void Dispose(bool isDisposing)
        {
            if (OnDispose != null)
                OnDispose();
            if(_properties != null)
            {
                foreach(var item in _properties.Values)
                {
                    IDisposable disposable = item as IDisposable;
                    if(disposable != null)
                        disposable.Dispose();
                }
                _properties.Clear();
                _properties = null;
            }
        }
    }
}
