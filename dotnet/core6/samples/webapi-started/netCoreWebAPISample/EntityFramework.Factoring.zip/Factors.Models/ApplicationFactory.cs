﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Factory.Models
{
    public abstract class _ApplicationFactory : IApplicationFactory
    {
        public _FactoryManager CreateFactoryManager(IPrincipal principal)
        {
            var manager = _FactoryManager.CreateFactoryManager();
            manager.Principal = principal;
            SetAdditionalProperties(manager);
            return manager;
        }

        public void SetAdditionalProperties(_FactoryManager manager)
        {
        }
    }
}
